
// Free variables are simply the variables that are neither locally declared nor passed as parameter.